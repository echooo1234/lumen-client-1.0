package dev.lumen;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.phys.Vec3;

/** Oyuncuların etrafına duvar arkasından da görünen kutu çizer. */
public final class PlayerEsp {
	private PlayerEsp() {
	}

	public static void collect() {
		if (!Module.PLAYER_ESP.isEnabled()) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		float partial = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
		boolean showSelf = Module.FREECAM.isEnabled();

		for (AbstractClientPlayer p : mc.level.players()) {
			if (p == mc.player && !showSelf) {
				continue;
			}
			Vec3 pos = p.getPosition(partial);
			double w = p.getBbWidth() / 2.0;
			double h = p.getBbHeight();

			float r = 1f, g = 0.15f, b = 0.15f; // normal: kırmızı
			if (p == mc.player) {
				r = 0.2f; g = 0.8f; b = 1f; // kendin: açık mavi
			} else if (p.isInvisible()) {
				r = 0.9f; g = 0.2f; b = 1f; // görünmez: mor
			} else if (p.isCrouching()) {
				r = 1f; g = 0.6f; b = 0.1f; // eğilmiş: turuncu
			}

			EspRenderer.submit(new EspRenderer.Box(pos.x - w, pos.y, pos.z - w, pos.x + w, pos.y + h, pos.z + w,
					r, g, b, 0.22f, true, false, 0));
			EspRenderer.submit(new EspRenderer.Box(pos.x - w, pos.y, pos.z - w, pos.x + w, pos.y + h, pos.z + w,
					r, g, b, 0.95f, false, true, 0.015));
		}
	}
}
