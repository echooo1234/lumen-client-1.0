package dev.lumen;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexFormat;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;

/**
 * Duvarların arkasını da gösteren kutu çizici.
 * Mantık Fabric'in "Rendering in the World" (1.21.11) dokümanındaki örnekten uyarlandı.
 */
public final class EspRenderer {
	/** Çizilecek tek bir kutu: dolgu ve/veya kenar çizgisi. */
	public record Box(double x0, double y0, double z0, double x1, double y1, double z1,
					  float r, float g, float b, float a, boolean fill, boolean outline, double thickness) {
	}

	private static final List<Box> BOXES = new ArrayList<>();

	private static final RenderPipeline FILLED_THROUGH_WALLS = RenderPipelines.register(
			RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
					.withLocation(Identifier.fromNamespaceAndPath("lumen", "pipeline/filled_box_through_walls"))
					.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
					.build());

	private static final ByteBufferBuilder ALLOCATOR = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
	private static BufferBuilder buffer;

	private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
	private static final Vector3f MODEL_OFFSET = new Vector3f();
	private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();
	private static MappableRingBuffer vertexBuffer;

	private EspRenderer() {
	}

	public static void init() {
		WorldRenderEvents.BEFORE_TRANSLUCENT.register(EspRenderer::onRender);
	}

	// ---------- kutu gönderme yardımcıları ----------

	public static void submit(Box box) {
		BOXES.add(box);
	}

	public static void block(int x, int y, int z, float r, float g, float b) {
		submit(new Box(x, y, z, x + 1, y + 1, z + 1, r, g, b, 0.25f, true, false, 0));
		submit(new Box(x, y, z, x + 1, y + 1, z + 1, r, g, b, 0.9f, false, true, 0.02));
	}

	// ---------- olay ----------

	private static void onRender(WorldRenderContext context) {
		BOXES.clear();
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null || mc.player == null) {
			return;
		}
		PlayerEsp.collect();
		ChestEsp.collect();
		PortalEsp.collect();
		BaseFinder.collect();

		if (BOXES.isEmpty()) {
			return;
		}

		PoseStack matrices = context.matrices();
		Vec3 camera = context.worldState().cameraRenderState.pos;

		matrices.pushPose();
		matrices.translate(-camera.x, -camera.y, -camera.z);

		if (buffer == null) {
			buffer = new BufferBuilder(ALLOCATOR, FILLED_THROUGH_WALLS.getVertexFormatMode(),
					FILLED_THROUGH_WALLS.getVertexFormat());
		}
		Matrix4fc m = matrices.last().pose();
		for (Box box : BOXES) {
			if (box.fill()) {
				addBox(m, buffer, box.x0(), box.y0(), box.z0(), box.x1(), box.y1(), box.z1(),
						box.r(), box.g(), box.b(), box.a());
			}
			if (box.outline()) {
				addOutline(m, buffer, box);
			}
		}
		matrices.popPose();

		drawBuffer(mc, FILLED_THROUGH_WALLS);
	}

	// ---------- geometri ----------

	private static void addOutline(Matrix4fc m, BufferBuilder b, Box k) {
		double t = k.thickness() <= 0 ? 0.02 : k.thickness();
		double[] xs = {k.x0(), k.x1()};
		double[] ys = {k.y0(), k.y1()};
		double[] zs = {k.z0(), k.z1()};
		for (double x : xs) {
			for (double z : zs) { // dikey kenarlar
				addBox(m, b, x - t, k.y0() - t, z - t, x + t, k.y1() + t, z + t, k.r(), k.g(), k.b(), k.a());
			}
		}
		for (double y : ys) {
			for (double z : zs) { // X boyunca
				addBox(m, b, k.x0() - t, y - t, z - t, k.x1() + t, y + t, z + t, k.r(), k.g(), k.b(), k.a());
			}
			for (double x : xs) { // Z boyunca
				addBox(m, b, x - t, y - t, k.z0() - t, x + t, y + t, k.z1() + t, k.r(), k.g(), k.b(), k.a());
			}
		}
	}

	private static void addBox(Matrix4fc m, BufferBuilder b, double dx0, double dy0, double dz0,
							   double dx1, double dy1, double dz1, float r, float g, float bl, float a) {
		float x0 = (float) dx0, y0 = (float) dy0, z0 = (float) dz0;
		float x1 = (float) dx1, y1 = (float) dy1, z1 = (float) dz1;
		face(m, b, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, r, g, bl, a); // ön
		face(m, b, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, r, g, bl, a); // arka
		face(m, b, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, r, g, bl, a); // sol
		face(m, b, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, r, g, bl, a); // sağ
		face(m, b, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, r, g, bl, a); // üst
		face(m, b, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, r, g, bl, a); // alt
	}

	private static void face(Matrix4fc m, BufferBuilder b,
							 float x1, float y1, float z1, float x2, float y2, float z2,
							 float x3, float y3, float z3, float x4, float y4, float z4,
							 float r, float g, float bl, float a) {
		b.addVertex(m, x1, y1, z1).setColor(r, g, bl, a);
		b.addVertex(m, x2, y2, z2).setColor(r, g, bl, a);
		b.addVertex(m, x3, y3, z3).setColor(r, g, bl, a);
		b.addVertex(m, x4, y4, z4).setColor(r, g, bl, a);
	}

	// ---------- GPU'ya yükleme ve çizim ----------

	private static void drawBuffer(Minecraft client, RenderPipeline pipeline) {
		MeshData built = buffer.buildOrThrow();
		MeshData.DrawState drawState = built.drawState();
		VertexFormat format = drawState.format();

		GpuBuffer vertices = upload(drawState, format, built);
		draw(client, pipeline, built, drawState, vertices);

		vertexBuffer.rotate();
		buffer = null;
	}

	private static GpuBuffer upload(MeshData.DrawState drawState, VertexFormat format, MeshData built) {
		int size = drawState.vertexCount() * format.getVertexSize();

		if (vertexBuffer == null || vertexBuffer.size() < size) {
			if (vertexBuffer != null) {
				vertexBuffer.close();
			}
			vertexBuffer = new MappableRingBuffer(() -> "lumen esp vertex buffer",
					GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE, size);
		}

		CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
		try (GpuBuffer.MappedView view = encoder.mapBuffer(
				vertexBuffer.currentBuffer().slice(0, built.vertexBuffer().remaining()), false, true)) {
			MemoryUtil.memCopy(built.vertexBuffer(), view.data());
		}
		return vertexBuffer.currentBuffer();
	}

	private static void draw(Minecraft client, RenderPipeline pipeline, MeshData built,
							 MeshData.DrawState drawState, GpuBuffer vertices) {
		GpuBuffer indices;
		VertexFormat.IndexType indexType;

		if (pipeline.getVertexFormatMode() == VertexFormat.Mode.QUADS) {
			built.sortQuads(ALLOCATOR, RenderSystem.getProjectionType().vertexSorting());
			indices = pipeline.getVertexFormat().uploadImmediateIndexBuffer(built.indexBuffer());
			indexType = built.drawState().indexType();
		} else {
			RenderSystem.AutoStorageIndexBuffer shared = RenderSystem.getSequentialBuffer(pipeline.getVertexFormatMode());
			indices = shared.getBuffer(drawState.indexCount());
			indexType = shared.type();
		}

		GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
				.writeTransform(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);

		try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
				() -> "lumen esp render pass",
				client.getMainRenderTarget().getColorTextureView(), OptionalInt.empty(),
				client.getMainRenderTarget().getDepthTextureView(), OptionalDouble.empty())) {
			pass.setPipeline(pipeline);
			RenderSystem.bindDefaultUniforms(pass);
			pass.setUniform("DynamicTransforms", dynamicTransforms);
			pass.setVertexBuffer(0, vertices);
			pass.setIndexBuffer(indices, indexType);
			pass.drawIndexed(0, 0, drawState.indexCount(), 1);
		}
		built.close();
	}
}
