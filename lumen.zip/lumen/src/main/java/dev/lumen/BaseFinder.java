package dev.lumen;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BeaconBlockEntity;
import net.minecraft.world.level.block.entity.BedBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BrewingStandBlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.block.entity.EnchantingTableBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

/**
 * Yüklü chunk'ları tarayıp "insan yapımı" izleri puanlar (sandık, fırın, hopper, beton, cam vb.).
 * Puanı eşiği geçen chunk'lar olası base olarak işaretlenir.
 * Not: köyler, kaleler ve madenler de puan alabilir (yanlış pozitif).
 */
public final class BaseFinder {
	public static int radiusChunks = 10;
	public static double threshold = 6.0;

	private static final int SCANS_PER_TICK = 3;
	private static final long RESCAN_TICKS = 600;

	public static final class Result {
		public final int cx, cz;
		public double score;
		public int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
		public long sumX, sumY, sumZ;
		public int points;
		public boolean notified;
		public long scannedAt;

		Result(int cx, int cz) {
			this.cx = cx;
			this.cz = cz;
		}

		public int centerX() {
			return points == 0 ? cx * 16 + 8 : (int) (sumX / points);
		}

		public int centerY() {
			return points == 0 ? 64 : (int) (sumY / points);
		}

		public int centerZ() {
			return points == 0 ? cz * 16 + 8 : (int) (sumZ / points);
		}

		void add(int x, int y, int z) {
			minY = Math.min(minY, y);
			maxY = Math.max(maxY, y);
			sumX += x;
			sumY += y;
			sumZ += z;
			points++;
		}
	}

	private static final Map<Long, Result> RESULTS = new HashMap<>();
	private static Level lastLevel;
	private static long ticks;
	private static Set<Block> unnatural;

	private BaseFinder() {
	}

	public static void reset() {
		RESULTS.clear();
		ticks = 0;
		lastLevel = null;
	}

	// ---------- "doğal olmayan" blok listesi ----------

	private static Set<Block> unnaturalBlocks() {
		if (unnatural == null) {
			Set<Block> set = new HashSet<>();
			for (Block block : BuiltInRegistries.BLOCK) {
				String path = BuiltInRegistries.BLOCK.getKey(block).getPath();
				if (path.endsWith("_concrete") || path.endsWith("_concrete_powder")
						|| path.endsWith("_glazed_terracotta") || path.endsWith("_stained_glass")
						|| path.endsWith("_stained_glass_pane")
						|| path.equals("diamond_block") || path.equals("emerald_block")
						|| path.equals("netherite_block") || path.equals("lodestone")
						|| path.equals("jukebox") || path.equals("note_block")
						|| path.equals("redstone_lamp") || path.equals("observer")
						|| path.equals("piston") || path.equals("sticky_piston")
						|| path.equals("repeater") || path.equals("comparator")) {
					set.add(block);
				}
			}
			unnatural = set;
		}
		return unnatural;
	}

	private static double weightOf(BlockEntity be) {
		if (be instanceof ShulkerBoxBlockEntity) return 3;
		if (be instanceof BeaconBlockEntity) return 5;
		if (be instanceof EnderChestBlockEntity || be instanceof EnchantingTableBlockEntity) return 2;
		if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity
				|| be instanceof AbstractFurnaceBlockEntity || be instanceof HopperBlockEntity
				|| be instanceof DispenserBlockEntity || be instanceof BrewingStandBlockEntity) return 1;
		if (be instanceof BedBlockEntity) return 0.5;
		return 0;
	}

	// ---------- tarama ----------

	public static void tick() {
		if (!Module.BASE_FINDER.isEnabled()) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null || mc.player == null) {
			return;
		}
		ticks++;
		if (mc.level != lastLevel) { // boyut/dünya değişti
			RESULTS.clear();
			lastLevel = mc.level;
		}

		int pcx = mc.player.chunkPosition().x;
		int pcz = mc.player.chunkPosition().z;

		// artık yüklü olmayan chunk'ları sil
		if (ticks % 100 == 0) {
			RESULTS.values().removeIf(r -> !mc.level.hasChunk(r.cx, r.cz));
		}

		// taranması gereken chunk'ları bul (en yakın önce)
		List<ChunkPos> todo = new ArrayList<>();
		for (int cx = pcx - radiusChunks; cx <= pcx + radiusChunks; cx++) {
			for (int cz = pcz - radiusChunks; cz <= pcz + radiusChunks; cz++) {
				if (!mc.level.hasChunk(cx, cz)) {
					continue;
				}
				Result old = RESULTS.get(ChunkPos.asLong(cx, cz));
				if (old == null || ticks - old.scannedAt > RESCAN_TICKS) {
					todo.add(new ChunkPos(cx, cz));
				}
			}
		}
		todo.sort(Comparator.comparingInt(p -> (p.x - pcx) * (p.x - pcx) + (p.z - pcz) * (p.z - pcz)));

		int done = 0;
		for (ChunkPos p : todo) {
			if (done++ >= SCANS_PER_TICK) {
				break;
			}
			scan(mc, p.x, p.z);
		}
	}

	private static void scan(Minecraft mc, int cx, int cz) {
		LevelChunk chunk = mc.level.getChunk(cx, cz);
		Result res = new Result(cx, cz);
		res.scannedAt = ticks;

		for (BlockEntity be : chunk.getBlockEntities().values()) {
			double w = weightOf(be);
			if (w > 0) {
				res.score += w;
				res.add(be.getBlockPos().getX(), be.getBlockPos().getY(), be.getBlockPos().getZ());
			}
		}

		Set<Block> set = unnaturalBlocks();
		int unnaturalCount = 0;
		LevelChunkSection[] sections = chunk.getSections();
		for (int i = 0; i < sections.length; i++) {
			LevelChunkSection section = sections[i];
			if (section.hasOnlyAir() || !section.maybeHas(s -> set.contains(s.getBlock()))) {
				continue;
			}
			int baseY = chunk.getSectionYFromSectionIndex(i) << 4;
			for (int x = 0; x < 16; x++) {
				for (int y = 0; y < 16; y++) {
					for (int z = 0; z < 16; z++) {
						if (set.contains(section.getBlockState(x, y, z).getBlock())) {
							unnaturalCount++;
							res.add((cx << 4) + x, baseY + y, (cz << 4) + z);
						}
					}
				}
			}
		}
		res.score += Math.min(unnaturalCount, 40) * 0.25;

		Result old = RESULTS.get(ChunkPos.asLong(cx, cz));
		if (old != null) {
			res.notified = old.notified;
		}
		if (res.score >= threshold && !res.notified && res.points > 0) {
			res.notified = true;
			mc.player.displayClientMessage(Component.literal(String.format(
					"§e[Lumen] §fOlası base: §bX %d Y %d Z %d §7(puan %.1f)",
					res.centerX(), res.centerY(), res.centerZ(), res.score)), false);
		}
		RESULTS.put(ChunkPos.asLong(cx, cz), res);
	}

	/** En yüksek puanlı chunk'lar. */
	public static List<Result> top(int n) {
		List<Result> list = new ArrayList<>();
		for (Result r : RESULTS.values()) {
			if (r.score >= threshold) {
				list.add(r);
			}
		}
		list.sort((a, b) -> Double.compare(b.score, a.score));
		return list.size() > n ? list.subList(0, n) : list;
	}

	// ---------- çizim ----------

	public static void collect() {
		if (!Module.BASE_FINDER.isEnabled()) {
			return;
		}
		for (Result r : RESULTS.values()) {
			if (r.score < threshold || r.points == 0) {
				continue;
			}
			float cr = 1f, cg = 0.9f, cb = 0.1f; // sarı
			if (r.score >= threshold * 4) {
				cr = 1f; cg = 0.1f; cb = 0.1f; // kırmızı: çok yoğun
			} else if (r.score >= threshold * 2) {
				cr = 1f; cg = 0.5f; cb = 0.1f; // turuncu
			}
			double x0 = r.cx * 16.0, z0 = r.cz * 16.0;
			double y0 = r.minY - 0.5, y1 = r.maxY + 1.5;
			EspRenderer.submit(new EspRenderer.Box(x0, y0, z0, x0 + 16, y1, z0 + 16, cr, cg, cb, 0.07f, true, false, 0));
			EspRenderer.submit(new EspRenderer.Box(x0, y0, z0, x0 + 16, y1, z0 + 16, cr, cg, cb, 0.9f, false, true, 0.06));
		}
	}
}
