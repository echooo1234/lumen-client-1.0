package dev.lumen.mixin;

import dev.lumen.Freecam;
import dev.lumen.Module;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;

/** Freecam açıkken kamerayı bizim konum/açıya taşır. */
@Mixin(Camera.class)
public abstract class CameraMixin {
	@Shadow
	protected abstract void setPosition(double x, double y, double z);

	@Shadow
	protected abstract void setRotation(float yRot, float xRot);

	@Inject(method = "setup", at = @At("RETURN"))
	private void lumen$setup(CallbackInfo ci) {
		if (!Module.FREECAM.isEnabled()) {
			return;
		}
		float partial = Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(true);
		setPosition(Freecam.camX(partial), Freecam.camY(partial), Freecam.camZ(partial));
		setRotation(Freecam.yaw(), Freecam.pitch());
	}

	/** Kendi karakterin de görünsün (üçüncü şahıs gibi). */
	@Inject(method = "isDetached", at = @At("HEAD"), cancellable = true)
	private void lumen$detached(CallbackInfoReturnable<Boolean> cir) {
		if (Module.FREECAM.isEnabled()) {
			cir.setReturnValue(true);
		}
	}
}
