package dev.lumen.mixin;

import dev.lumen.AntiVanish;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundCommandSuggestionsPacket;

/** Anti-vanish isteğimize gelen komut önerisi cevabını yakalar (sohbet kutusuna gitmesin). */
@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerMixin {
	@Inject(method = "handleCommandSuggestions", at = @At("HEAD"), cancellable = true)
	private void lumen$suggestions(ClientboundCommandSuggestionsPacket packet, CallbackInfo ci) {
		if (packet.id() == AntiVanish.REQUEST_ID) {
			AntiVanish.onSuggestions(packet.toSuggestions());
			ci.cancel();
		}
	}
}
