package dev.lumen;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import com.mojang.brigadier.suggestion.Suggestion;
import com.mojang.brigadier.suggestion.Suggestions;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundCommandSuggestionPacket;

/**
 * Vanish'te olan oyuncuları bulmaya çalışır: sunucudan "/msg " komut önerilerini ister
 * (öneri listesi çevrimiçi herkesi içerir) ve bunu tab listesiyle karşılaştırır.
 * Önerilerde olup tab listesinde olmayan isimler vanish şüphelisidir.
 * Not: tab listesini bilerek gizleyen sunucularda yanlış pozitif verebilir.
 */
public final class AntiVanish {
	public static final int REQUEST_ID = 0x4C554D;
	private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_.]{1,16}");
	private static final Set<String> FLAGGED = new HashSet<>();
	private static int tickCounter;

	private AntiVanish() {
	}

	public static void reset() {
		FLAGGED.clear();
		tickCounter = 0;
	}

	public static void tick() {
		if (!Module.ANTI_VANISH.isEnabled()) {
			return;
		}
		if (tickCounter++ % 100 != 0) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		if (mc.getConnection() == null || mc.player == null || mc.hasSingleplayerServer()) {
			return;
		}
		mc.getConnection().send(new ServerboundCommandSuggestionPacket(REQUEST_ID, "/msg "));
	}

	/** Mixin tarafından, bizim isteğimize gelen cevapla çağrılır. */
	public static void onSuggestions(Suggestions suggestions) {
		Minecraft mc = Minecraft.getInstance();
		if (!Module.ANTI_VANISH.isEnabled() || mc.getConnection() == null || mc.player == null) {
			return;
		}
		Set<String> tab = new HashSet<>();
		for (PlayerInfo info : mc.getConnection().getOnlinePlayers()) {
			tab.add(info.getProfile().name());
		}
		String self = mc.player.getGameProfile().name();

		Set<String> suspects = new HashSet<>();
		for (Suggestion s : suggestions.getList()) {
			String name = s.getText();
			if (NAME.matcher(name).matches() && !tab.contains(name) && !name.equals(self)) {
				suspects.add(name);
			}
		}

		for (String name : suspects) {
			if (FLAGGED.add(name)) {
				mc.player.displayClientMessage(
						Component.literal("§c[Lumen] §fVanish şüphesi: §e" + name), false);
			}
		}
		FLAGGED.retainAll(suspects); // artık görünür/çıkmış olanları listeden düş
	}
}
