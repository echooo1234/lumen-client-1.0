package dev.lumen;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;

public class LumenClient implements ClientModInitializer {
	private static final Map<Module, KeyMapping> KEYS = new EnumMap<>(Module.class);
	private static KeyMapping menuKey;

	@Override
	public void onInitializeClient() {
		KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("lumen", "main"));

		// Menü tuşu: varsayılan Sol Shift (Controls menüsünden değiştirilebilir)
		menuKey = KeyBindingHelper.registerKeyBinding(
				new KeyMapping("key.lumen.menu", InputConstants.Type.KEYSYM, InputConstants.KEY_LSHIFT, category));
		ContainerMemory.init();

		// Varsayılan tuşlar: V = freecam, Numpad 1-5 = diğer modüller (Controls menüsünden değiştirilebilir)
		bind(category, Module.FREECAM, "key.lumen.freecam", InputConstants.KEY_V);
		bind(category, Module.PLAYER_ESP, "key.lumen.player_esp", InputConstants.KEY_NUMPAD1);
		bind(category, Module.CHEST_ESP, "key.lumen.chest_esp", InputConstants.KEY_NUMPAD2);
		bind(category, Module.PORTAL_ESP, "key.lumen.portal_esp", InputConstants.KEY_NUMPAD3);
		bind(category, Module.BASE_FINDER, "key.lumen.base_finder", InputConstants.KEY_NUMPAD4);
		bind(category, Module.ANTI_VANISH, "key.lumen.anti_vanish", InputConstants.KEY_NUMPAD5);

		EspRenderer.init();
		ClientTickEvents.END_CLIENT_TICK.register(LumenClient::onTick);
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> registerCommands(dispatcher));
	}

	private static void bind(KeyMapping.Category category, Module module, String translationKey, int keyCode) {
		KEYS.put(module, KeyBindingHelper.registerKeyBinding(
				new KeyMapping(translationKey, InputConstants.Type.KEYSYM, keyCode, category)));
	}

	private static void onTick(Minecraft mc) {
		if (mc.level == null || mc.player == null) {
			Module.disableAll(); // dünyadan çıkınca her şey kapanır
			return;
		}
		while (menuKey.consumeClick()) {
			if (mc.screen == null) {
				mc.setScreen(new LumenScreen());
			}
		}
		for (Map.Entry<Module, KeyMapping> e : KEYS.entrySet()) {
			while (e.getValue().consumeClick()) {
				e.getKey().toggle();
			}
		}
		ContainerMemory.tick();
		Freecam.tick();
		ChestEsp.tick();
		PortalEsp.tick();
		BaseFinder.tick();
		AntiVanish.tick();
	}

	// ---------- komutlar: /lumen ... ----------

	private static void registerCommands(com.mojang.brigadier.CommandDispatcher<FabricClientCommandSource> dispatcher) {
		LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("lumen");

		for (Module m : Module.values()) {
			root.then(ClientCommandManager.literal(m.id).executes(ctx -> {
				m.toggle();
				return 1;
			}));
		}

		root.then(ClientCommandManager.literal("bases").executes(ctx -> {
			List<BaseFinder.Result> top = BaseFinder.top(10);
			Minecraft mc = Minecraft.getInstance();
			if (top.isEmpty()) {
				ctx.getSource().sendFeedback(Component.literal("§7[Lumen] Henüz olası base yok (Base Bulucu açık mı?)"));
				return 1;
			}
			for (BaseFinder.Result r : top) {
				double dist = mc.player == null ? 0
						: Math.sqrt(mc.player.distanceToSqr(r.centerX(), r.centerY(), r.centerZ()));
				ctx.getSource().sendFeedback(Component.literal(String.format(
						"§e[Lumen] §fX %d Y %d Z %d §7(puan %.1f, %d blok uzakta)",
						r.centerX(), r.centerY(), r.centerZ(), r.score, (int) dist)));
			}
			return 1;
		}));

		root.then(ClientCommandManager.literal("speed").then(
				ClientCommandManager.argument("deger", DoubleArgumentType.doubleArg(0.05, 10))
						.executes(ctx -> {
							Freecam.speed = DoubleArgumentType.getDouble(ctx, "deger");
							ctx.getSource().sendFeedback(Component.literal("§7[Lumen] Freecam hızı: " + Freecam.speed));
							return 1;
						})));

		root.then(ClientCommandManager.literal("radius").then(
				ClientCommandManager.argument("chunk", IntegerArgumentType.integer(2, 32))
						.executes(ctx -> {
							int v = IntegerArgumentType.getInteger(ctx, "chunk");
							ChestEsp.radiusChunks = v;
							PortalEsp.radiusChunks = Math.min(v, 12);
							BaseFinder.radiusChunks = v;
							ctx.getSource().sendFeedback(Component.literal("§7[Lumen] Tarama yarıçapı: " + v + " chunk"));
							return 1;
						})));

		root.then(ClientCommandManager.literal("esik").then(
				ClientCommandManager.argument("puan", DoubleArgumentType.doubleArg(1, 200))
						.executes(ctx -> {
							BaseFinder.threshold = DoubleArgumentType.getDouble(ctx, "puan");
							ctx.getSource().sendFeedback(Component.literal(
									"§7[Lumen] Base eşiği: " + BaseFinder.threshold));
							return 1;
						})));

		root.executes(ctx -> {
			StringBuilder sb = new StringBuilder("§7[Lumen] Modüller: ");
			for (Module m : Module.values()) {
				sb.append(m.isEnabled() ? "§a" : "§c").append(m.id).append("§7, ");
			}
			sb.append("\n§7Komutlar: /lumen <modül> | bases | speed <n> | radius <chunk> | esik <puan>");
			ctx.getSource().sendFeedback(Component.literal(sb.toString()));
			return 1;
		});

		dispatcher.register(root);
	}
}
