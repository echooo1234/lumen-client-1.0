package dev.lumen;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** Açılıp kapanabilen modüller ve durumları. */
public enum Module {
	PLAYER_ESP("playeresp", "Oyuncu ESP"),
	CHEST_ESP("chestesp", "Sandık ESP"),
	PORTAL_ESP("portalesp", "Portal ESP"),
	BASE_FINDER("basefinder", "Base Bulucu"),
	ANTI_VANISH("antivanish", "Anti Vanish"),
	FREECAM("freecam", "Freecam");

	public final String id;
	public final String title;
	private boolean enabled;

	Module(String id, String title) {
		this.id = id;
		this.title = title;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void toggle() {
		setEnabled(!enabled);
	}

	public void setEnabled(boolean value) {
		if (value == enabled) {
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		if (value && this == FREECAM && mc.player == null) {
			return;
		}
		enabled = value;
		switch (this) {
			case FREECAM -> Freecam.onToggle(value);
			case ANTI_VANISH -> AntiVanish.reset();
			case BASE_FINDER -> BaseFinder.reset();
			case CHEST_ESP -> ChestEsp.reset();
			case PORTAL_ESP -> PortalEsp.reset();
			default -> {
			}
		}
		if (mc.player != null) {
			mc.player.displayClientMessage(
					Component.literal("§7[Lumen] §f" + title + (value ? " §aAÇIK" : " §cKAPALI")), true);
		}
	}

	public static Module byId(String id) {
		for (Module m : values()) {
			if (m.id.equalsIgnoreCase(id)) {
				return m;
			}
		}
		return null;
	}

	public static void disableAll() {
		for (Module m : values()) {
			m.enabled = false;
		}
		Freecam.onToggle(false);
	}
}
