package dev.lumen;

import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Wurst tarzı basit menü: modülleri açıp kapatır, birkaç ayarı değiştirir. */
public class LumenScreen extends Screen {
	private static final int COL_W = 140;
	private static final int GAP = 12;
	private static final int ROW = 24;
	private static final int HEADER = 20;

	private int left;
	private int top;

	public LumenScreen() {
		super(Component.literal("Lumen"));
	}

	@Override
	protected void init() {
		int totalW = 3 * COL_W + 2 * GAP;
		left = (this.width - totalW) / 2;
		top = this.height / 2 - 70;

		// 1. pencere: Görsel
		int x = left;
		int y = top + HEADER + 6;
		moduleButton(x, y, Module.PLAYER_ESP);
		moduleButton(x, y + ROW, Module.CHEST_ESP);
		moduleButton(x, y + 2 * ROW, Module.PORTAL_ESP);
		cycleButton(x, y + 3 * ROW, "Sandık yarıçapı", new double[]{4, 6, 8, 12, 16},
				() -> ChestEsp.radiusChunks, v -> ChestEsp.radiusChunks = (int) v);

		// 2. pencere: Bulucu
		x = left + COL_W + GAP;
		moduleButton(x, y, Module.BASE_FINDER);
		moduleButton(x, y + ROW, Module.ANTI_VANISH);
		cycleButton(x, y + 2 * ROW, "Base yarıçapı", new double[]{4, 6, 8, 10, 14, 20},
				() -> BaseFinder.radiusChunks, v -> BaseFinder.radiusChunks = (int) v);
		cycleButton(x, y + 3 * ROW, "Base eşiği", new double[]{3, 6, 10, 15, 25, 40},
				() -> BaseFinder.threshold, v -> BaseFinder.threshold = v);

		// 3. pencere: Kamera
		x = left + 2 * (COL_W + GAP);
		moduleButton(x, y, Module.FREECAM);
		cycleButton(x, y + ROW, "Freecam hızı", new double[]{0.3, 0.6, 0.9, 1.5, 2.5, 4},
				() -> Freecam.speed, v -> Freecam.speed = v);

		this.addRenderableWidget(Button.builder(Component.literal("Kapat"), b -> this.onClose())
				.bounds(this.width / 2 - 50, top + HEADER + 6 + 4 * ROW + 10, 100, 20).build());
	}

	private void moduleButton(int x, int y, Module m) {
		this.addRenderableWidget(Button.builder(moduleLabel(m), b -> {
			m.toggle();
			b.setMessage(moduleLabel(m));
		}).bounds(x + 5, y, COL_W - 10, 20).build());
	}

	private static Component moduleLabel(Module m) {
		return Component.literal(m.title + ": " + (m.isEnabled() ? "§aAÇIK" : "§cKAPALI"));
	}

	/** Tıklayınca değerler arasında döner. */
	private void cycleButton(int x, int y, String name, double[] values, DoubleSupplier get, DoubleConsumer set) {
		this.addRenderableWidget(Button.builder(cycleLabel(name, get.getAsDouble()), b -> {
			double cur = get.getAsDouble();
			int next = 0;
			for (int i = 0; i < values.length; i++) {
				if (values[i] > cur + 1e-9) {
					next = i;
					break;
				}
			}
			set.accept(values[next]);
			b.setMessage(cycleLabel(name, values[next]));
		}).bounds(x + 5, y, COL_W - 10, 20).build());
	}

	private static Component cycleLabel(String name, double v) {
		String s = Math.abs(v - Math.rint(v)) < 1e-9 ? String.valueOf((long) Math.rint(v)) : String.valueOf(v);
		return Component.literal(name + ": §e" + s);
	}

	@Override
	public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		super.renderBackground(g, mouseX, mouseY, partialTick);
		String[] titles = {"Görsel", "Bulucu", "Kamera"};
		int bodyH = HEADER + 6 + 4 * ROW + 6;
		for (int i = 0; i < 3; i++) {
			int x = left + i * (COL_W + GAP);
			g.fill(x, top, x + COL_W, top + bodyH, 0xCC14141C); // pencere gövdesi
			g.fill(x, top, x + COL_W, top + HEADER, 0xFF6A3DE8); // başlık çubuğu
			g.drawCenteredString(this.font, Component.literal(titles[i]), x + COL_W / 2, top + 6, 0xFFFFFFFF);
		}
	}

	@Override
	public boolean isPauseScreen() {
		return false; // menü açıkken oyun durmasın
	}
}
